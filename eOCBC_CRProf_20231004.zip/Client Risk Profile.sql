select A.no_cust,A.block,A.open_date,A.flag,A.birthplace,A.birthdate,A.npwp,A.no_id,A.no_staff,C.name salesname,B.email,
A.investor_no,A.job,B.occupation,dbo.GetClientCode(A.npwp) accowned,B.salary,B.company,B.job_title,B.
from sas_ii.dbo.subacc A join sas_ii.dbo.masteracc B on A.no_cust = B.no_cif 
join sas_ii.dbo.staff C on A.no_staff = C.no_staff
Where A.block not in ('C','D')

select * from sas_ii.dbo.masteracc

