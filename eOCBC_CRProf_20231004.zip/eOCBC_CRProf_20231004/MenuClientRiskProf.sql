use eOCBC
declare @obj_id int
select @obj_id =  max(ObjectId)  from mgr.MsObjectLibrary

set @obj_id += 1
--select * from mgr.MsObjectLibrary where modid = 'ST'
insert into mgr.MsObjectLibrary values (@obj_id,'RS','Client Risk Profile','FrmClientRiskProf','S','N','mgr',getdate(),null,null,null)

declare @menuno int, @parentmenuno int
--select @obj_id = objectid from mgr.MsObjectLibrary where ObjectName = 'FrmIntMarg'

--select @obj_id
select @parentmenuno = MenuNo from mgr.MsUserMenu where MenuName = 'Risk Management'


declare @seqno int
select @seqno = max(seqno) from mgr.MsUserMenu where ParentMenuNo = @parentmenuno
select @menuno = max(menuno) from mgr.MsUserMenu 

set @menuno += 1
set @seqno += 1

select @obj_id = objectid  from mgr.MsObjectLibrary where  ObjectName = 'FrmClientRiskProf'
insert into mgr.MsUserMenu Values(@menuno,'Administrator',@seqno,'S','Client Risk Profile',@obj_id,@parentmenuno,'00060.ico','mgr',getdate(),null,null,null)
insert into mgr.MsUserMenu Values(@menuno,'mgr',@seqno,'S','Client Risk Profile',@obj_id,@parentmenuno,'00060.ico','mgr',getdate(),null,null,null)

